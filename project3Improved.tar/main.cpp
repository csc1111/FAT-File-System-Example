#include "Sdisk.h"
#include <iostream>
#include <iomanip>
#include <string>
#include <sstream>
#include <vector>
#include <fstream>
#include <cmath>

using namespace std;


Sdisk::Sdisk(string diskname, int numberofblocks, int blocksize)
{
     this->diskname = diskname;
     this->numberofblocks = numberofblocks;
     this->blocksize = blocksize;
     fstream iofile;
     iofile.open(diskname.c_str(), ios::in);
     if(iofile.good())
     {
          cout << "File exists" << endl;
     }
        else
     {
          cout << "File does not exist. Creating file " << diskname << " " << endl;
          iofile.open(diskname.c_str(), ios::out);
          for(int i=0; i<(blocksize*numberofblocks); i++)
          {
               iofile.put('#');
          }

     }
     iofile.close();
}
int Sdisk::getblock(int blocknumber, string& buffer)
{
        fstream infile;
        infile.open(diskname.c_str(), ios::in);
        infile.seekg(blocknumber*blocksize);
        if(infile.good()){
                for(int i=0; i<blocksize; i++){
                        buffer += infile.get();
                }
                infile.close();
                return 1;
        }
        else{
                return 0;
        }
}

int Sdisk::putblock(int blocknumber, string buffer)
{
     fstream outfile;
     outfile.open(diskname.c_str(), ios::in | ios::out);
     outfile.seekg(blocknumber*blocksize);
     if(outfile.good())
     {
          for(int i=0; i<buffer.length() && i<blocksize; i++)
          {
               outfile.put(buffer[i]);
          }
          outfile.close();
          return 1;
     }
     else
     {
          cout << "failed to write to file" << diskname << " " << endl;
          return 0;
     }
}

int Sdisk::getnumberofblocks(){
        return numberofblocks;
}

int Sdisk::getblocksize(){
        return blocksize;
}
Filesys::Filesys(string file, int numberofblocks, int blocksize):Sdisk(file,numberofblocks,blocksize){
    cout<<"FILESYS"<<endl;
        string buffer;
        rootsize = getblocksize()/12;
        fatsize = ((getnumberofblocks()*6)/(getblocksize()))+1;
        cout<<"fatsize:"<<fatsize;
        getblock(1,buffer);
        if(buffer[0]=='#'){
                cout<<"No File System"<<endl;

                for(int i=0; i<rootsize; i++){
                        filename.push_back("XXXXX");
                        firstblock.push_back(0);
                }

                fat.push_back(fatsize+2);
                fat.push_back(-1);

                for(int i=0; i<fatsize; i++){
                        fat.push_back(-1);
                }

                for(int i=2+fatsize; i<getnumberofblocks(); i++){
                        fat.push_back(i+1);
                }
                fat[getnumberofblocks()-1] = -1;
                cout<<"Created File System"<<endl;
       }
       else{
                cout<<"File System Exists"<<endl;
                string buffer;
                istringstream readroot;
                readroot >> buffer;
                for(int i = 0; i < rootsize; i++){
                        string s;
                        int n;
                        readroot >> s >> n;
                        filename.push_back(s);
                        firstblock.push_back(n);
                }
                string fatbuffer;
                for(int i = 0; i < fatsize; i++){
                        string s;
                        getblock(i + 2, s);
                        fatbuffer += s;
                }
                istringstream fatstream;
                fatstream.str(fatbuffer);
                for(int i = 0; i < getnumberofblocks(); i++){
                        int temp;
                        fatstream >> temp;
                        fat.push_back(temp);
                }

       }
       /*
       //cout<<"fatsize:"<<fatsize<<endl;
       //fat[0] = fatsize + 2; // Assuming the first free block starts at fatsize + 2
       //cout<<"fat[0]:"<<fat[0]<<endl;
       cout<<"*************fat[]*************************"<<endl;
        for(int i=0;i<getnumberofblocks();++i)
                cout<<fat[i]<<" ";
        cout<<endl;
        cout<<"**FILESYSEND**"<<endl;
	*/
        fssynch();
}

vector<string> block(string buffer, int b){
  vector<string> blocks;
  int numberofblocks=0;

  if (buffer.length() % b == 0){
    numberofblocks= buffer.length()/b;
  }
  else{
    numberofblocks= buffer.length()/b +1;
  }

  string tempblock;
  for (int i=0; i<numberofblocks; i++){
    tempblock=buffer.substr(b*i,b);
    blocks.push_back(tempblock);
  }

  int lastblock=blocks.size()-1;

  for (int i=blocks[lastblock].length(); i<b; i++){
    blocks[lastblock]+="#";
  }

  return blocks;
}

int Filesys::fsclose(){
        fssynch();
        return 0;
}

int Filesys::fssynch(){
        ostringstream rootstream;

        for(int i = 0; i < rootsize; ++i){
                rootstream << filename[i] << " " << firstblock[i] << " ";
		//cout<<endl;
		//cout<<"firstblock"<<filename[i]<<":"<<firstblock[i]<<endl;
        }
        string root = rootstream.str();
        for(long j = root.size(); j < getblocksize(); j++){
                root += "#";
        }

        putblock(1, root);

        ostringstream fatstream;

        for(int i = 0; i < getnumberofblocks(); i++){
                fatstream << fat[i] << " ";
		//cout<<fat[i]<<" ";
        }
        string fatstring = fatstream.str();

        vector<string> blocks=block(fatstring,getblocksize());

        for(int i = 0; i < blocks.size(); i++){
                putblock(i+2, blocks[i]);
        }
	//cout<<"FAT{0}:"<<fat[0]<<endl;
        return 1;
}

int Filesys::newfile(string file){


        for(int i=0; i<filename.size(); i++){
            if(filename[i] == file){
                cout << "File " << file << " already exists." << endl;
                return 1;
            }
        }

        for(int i=0; i<filename.size(); i++)
	{
		cout<<"filename "<<i<<":  "<<filename[i]<<endl;
            if (filename[i] == "XXXXX"){
                cout << "Creating file " << file << endl;
                filename[i] = file;
                firstblock[i]=0;
                break;
            }
        }
	//cout<<"file empty";
        fssynch();
        return 1;
}

int Filesys::rmfile(string file){
        for(int i = 0; i < filename.size(); i++) {
                if(filename[i] == file && firstblock[i] == 0) {
                        filename[i] = "XXXXX";
                        firstblock[i] = -1;
                }
        }
	cout<<endl;
	cout<<"FILE: "<<file<<" Gone"<<endl;
	//cout<<"FAT[0]"<<fat[0]<<endl;
        fssynch();
        return 1;
}

int Filesys::getfirstblock(string file){
        int first_block = -1;
        for(int i=0; i<filename.size(); i++){
	//	cout<<"GET I<<"<<i<<"/"<<filename.size()<<endl;
                if(filename[i]==file){
                        first_block = firstblock[i];
			//cout<<"GiFirst block:"<<firstblock[i]<<endl;
                        break;
                }
        }
        fssynch();
	if(first_block==-1)
		cout<<"file not found"<<endl;
        return first_block;
}

int Filesys::addblock(string file, string buffer){
        int fstblock = getfirstblock(file);
	int allocate = fat[0];
	//cout<<endl;
	//cout<<allocate;	
	if(fstblock==-1){
		cout<<"error";
		return 0;
	}
        if(allocate == 0) {
                cout << "Disk is full!" << endl;
                return -1;

        }

	

	fat[0]=fat[fat[0]];
	fat[allocate]=0;

        if(fstblock == 0) {//file is emptyi
		//cout<<"FATIF:";
                for(int i = 0; i < filename.size(); i++) {
                        if(filename[i] == file) 
			{
				
					
                                //fstblock = block;
				firstblock[i]=allocate;
				
                                //cout<<"fat[0] fat[fat[0]] fat[all] alloc"<<endl;
				//cout<<fat[0]<<"  "<<fat[fat[0]]<<"  "<<fat[allocate]<<"  "<<allocate<<endl;
				break;
                        }
                }
        }
        else {
		//cout<<endl;
		
                
                while(fat[fstblock] != 0) {
                	fstblock = fat[fstblock];
		}
                fat[fstblock] = allocate;
                	
                
        }
        putblock(allocate, buffer);
        fssynch();
	
	//cout<<"NEWBLOCK IN ADD:"<<allocate<<endl;
	//cout<<"*************fat[]ADD*************************"<<endl;
        //for(int i=0;i<getnumberofblocks();++i)
        //      cout<<fat[i]<<" ";
	//cout<<endl;
        return allocate;
}

int Filesys::delblock(string file, int blocknumber){
	

	/*
	cout<<endl;	
	cout<<"DEL:"<<endl;
	cout<<"fat[0};"<<fat[0]<<endl;
        cout<<"bnfat["<<blocknumber<<"]:"<<fat[blocknumber]<<endl;

	cout<<endl;
	for(int i = 0; i < 50; i++){
     		cout<<fat[i]<<" ";
        }
	*/
	int deallocate=blocknumber;

	if(blocknumber==getfirstblock(file)){
		cout<<"IF RAN IN DEL"<<endl;

		for(int i=0; i<filename.size();++i){
			if(file==filename[i]){
				//cout<<"nestedif"<<firstblock[i]<<endl;
				firstblock[i]=fat[blocknumber];
			
                                
		
				break;
			}
		}
	}
	else{
		cout<<"ELSE IN DEL RAN"<<endl;
		int b=getfirstblock(file);
		while(fat[b]!=blocknumber){
			b=fat[b];
		}
		fat[b]=fat[blocknumber];
	}

	fat[blocknumber] = fat[0];
        fat[0] = blocknumber;
 	/*cout<<"*******************************"<<endl;
        for(int i = 0; i < 50; i++){
                cout<<fat[i]<<" ";
        }
*/
        
        fssynch();
        return 1;


/****
	cout<<endl;
	cout<<endl;
	cout<<"DEL BLOCK NUMBER AT START:"<<blocknumber<<endl;
	cout<<"fat[0};"<<fat[0]<<endl;
	cout<<"bnfat["<<blocknumber<<"]:"<<fat[blocknumber]<<endl;
	cout<<"fat{"<<"13]:"<<fat[13]<<"  "<<endl;
	cout<<"Firstblock of file:"<<file<<getfirstblock(file)<<endl;
	cout<<"*************fat[]Del*************************"<<endl;
	for(int i=0;i<fatsize;++i)
	//	cout<<fat[i]<<" ";

        if(blocknumber == getfirstblock(file)) {

                for(int i = 0; i < filename.size(); i++) {
                        if(filename[i] == file) {
                                firstblock[i] = fat[blocknumber];
				for(int i = 0; i < getnumberofblocks(); i++){
         		       		cout<<fat[i]<<" ";
        			}
                        }
                }
        }
else {
        // General case: Deleting a block that is not the first block
        int currentBlock = getfirstblock(file);
        int prevBlock = -1; // Initialize previous block as invalid
	
	for(int i = 0; i < getnumberofblocks(); i++){
                cout<<fat[i]<<" ";
        }

        // Traverse the block chain
        while (currentBlock != 0 && currentBlock != blocknumber) {
            prevBlock = currentBlock;
            currentBlock = fat[currentBlock];
        }

        if (currentBlock == 0) {
            // Block not found in the file's block chain
            cout << "Error: Block number not found in the file." << endl;
            return -1;
        }
        
        // Update the FAT to bypass the deleted block
        if (prevBlock != -1) {
            fat[prevBlock] = fat[blocknumber];
        }
    }	
  fat[blocknumber] = fat[0]; // Point deleted block to the current free list head
    fat[0] = blocknumber; // Update free list head to the deleted block

    // Synchronize the file system to disk
    fssynch();

    return 1; // Successful deletion

******/
	
	/*
        else {
                int blockid=getfirstblock(file);
		int count=0;
                while(fat[blockid] != blocknumber&&count<90) {
			count++;
			cout<<endl;
			cout<<"bloacknumber:"<<blocknumber<<endl;
			cout<<"fat["<<blockid<<"]:"<<fat[blockid]<<endl;
                        blockid = fat[blockid];
			
                }
                fat[blockid] = fat[blocknumber];
        }
	//cout<<"line290:"<<fat[0]<<endl;
        fat[blocknumber] = fat[0];
        fat[0] = blocknumber;
	//cout<<"DEL fat[0]:"<<fat[0]<<endl;
        fssynch();
	return 1;*/
}



int Filesys::readblock(string file, int blocknumber, string& buffer){
        getblock(blocknumber,buffer);
        return 1;
}
int Filesys::writeblock(string file, int blocknumber, string buffer){
        putblock(blocknumber,buffer);
        return 1;
}

int Filesys::nextblock(string file, int blocknumber){
        int blockid = getfirstblock(file);
        while(blockid != blocknumber){
                blockid = fat[blockid];
        }
        return fat[blockid];
}

vector<string> Filesys::ls(){
  vector<string> flist;
 
  cout<<"*************************fat[]*************************"<<endl;
  string temp;
  for(int i = 0; i < getnumberofblocks(); i++){
                cout<<fat[i]<<" ";
		
        }

  

  
  for (int i=0; i<filename.size(); i++)
      {
        if (filename[i] != "XXXXX")
           {
             flist.push_back(filename[i]);
           }
      }

  return flist;
}

Shell::Shell(string filename, int numberofblocks, int blocksize):Filesys(filename, numberofblocks,blocksize){

}

int Shell::dir(){			//list files
	vector<string> flist=ls();

	string t;
	
	cout<<"*************************Blocks*************************"<<endl;
	for (int i = 0;  i<getnumberofblocks(); i++)
    	{
        	string buffer;
	        getblock(i, buffer);
        	cout << "Block " << i << ": " << buffer << endl;
        }
	
	cout<<"*************************file list*************************"<<endl;
	for (int i=0; i<flist.size(); i++)
      	{
        	cout << flist[i] << endl;
      	
	}
	return 0;
}

int Shell::add(string file,string buffer){// add a new file using buffer as data

	int fb=getfirstblock(file);
	string b;

	if(fb>=0){
		cout<<"File exists"<<fb<<endl;
		return 0;
	}
	int code=newfile(file);

	if(code==0){
		cout<<"CANT DO IT!";
		return 0;
	}

	vector<string> blocks=block(buffer,getblocksize());
	int c=0;
	cout<<"add:";
	cout<<file;

	for(int i=0;i<blocks.size();++i){
		c =addblock(file,blocks[i]);
	}

	/*
	for(int i=0;i<256;++i){
		getblock(i, b);
        	cout << "Glock " << i << ": " << b << endl;
	}

	cout<<"addblock ran"<<endl;
	*/
	return 1;
}


int Shell::del(string file){// deletes the file
	
	

	if(getfirstblock(file)==-1){
		cout<<"FILE NO EXIST";
		return 0;
	}

	while(getfirstblock(file)!=0){
		delblock(file,getfirstblock(file));
	
		cout<<"while";
	}
	rmfile(file);
	return 1;
}

int Shell::type(string file){//lists the contents of file

	int b=getfirstblock(file);
	if(b==-1){
		cout<<"file doesnt exist";
		return 0;
	}
	if(b==0)
		return 1;

	cout<<endl;
	while(b!=0){
		
		string buffer;
		readblock(file,b,buffer);
		cout<<buffer;
		b=nextblock(file,b);
	}
	cout<<endl;

	return 1;
}

int Shell::copy(string file1, string file2){//copies file1 to file
	int code=newfile(file2);

	if(code==0){
		return 0;
	}

	int b=getfirstblock(file1);
	while(b!=0){
		string buffer;
		readblock(file1,b,buffer);
		addblock(file2,buffer);
		b= nextblock(file1,b);
	}


	return 1;
}



/*

int main()
{
  Sdisk disk1("disk1",256,128);
  Filesys fsys("disk1",256,128);
  fsys.newfile("file1");
  fsys.newfile("file2");

  string bfile1;
  string bfile2;

  for (int i=1; i<=1024; i++)
     {
       bfile1+="1";
     }

  vector<string> blocks=block(bfile1,128);

        int blocknumber=0;
        cout<<"blocks size"<<blocks.size();

  for (int i=0; i< blocks.size(); i++)
     {
       blocknumber=fsys.addblock("file1",blocks[i]);
        //cout<<blocks[i]<<"x"<<endl;
     }

for (int i = 0;  i< 256; i++)
    {
        string buffer;
        fsys.getblock(i, buffer);
        cout << "Glock " << i << ": " << buffer << endl;
	}
        fsys.delblock("file1",fsys.getfirstblock("file1"));



  for (int i=1; i<=2048; i++)
     {
       bfile2+="2";
     }

  blocks=block(bfile2,128);
cout<<"blocks size"<<blocks.size();
  for (int i=0; i< blocks.size(); i++)
     {
             cout<<endl;
                cout<<"blocknumber:"<<blocknumber<<" | blocks[i]"<<blocks[i] <<" i:"<<i<<endl;
                //
                blocknumber=fsys.addblock("file2",blocks[i]);
                //cout<<blocknumber<<"X"<<endl;
     }
        cout<<endl;
        cout<<endl;

        for (int i = 0;  i< 256; i++)
        {
                string buffer;
                fsys.getblock(i, buffer);
                cout << "Bock " << i << ": " << buffer << endl;
        }

  fsys.delblock("file2",blocknumber);

  for (int i = 0;  i< 256; i++)
    {
        string buffer;
        fsys.getblock(i, buffer);
        cout << "Block " << i << ": " << buffer << endl;
    }

	return 0;
}



*/
// You can use this to test your Filesys class 
int main()
{
 //
 //This main program inputs commands to the shell.
 //It inputs commands as : command op1 op2
 //You should modify it to work for your implementation.
 //
 
 Shell shell=Shell("disk.txt",256,128);
 string s;
 string command="go";
 string op1,op2;
 string bfile1;
 string bfile2;

 for (int i=1; i<=1024; i++)
     {
       bfile1+="1";
     }


  for (int i=1; i<=2048; i++)
     {
       bfile2+="2";
     }

 while (command != "quit")
     {
       command.clear();
       op1.clear();
       op2.clear();
       cout<<"bfile1 for 1024 blocks of 1 and bfile2 for 2048 blocks of 2"<<endl;
       cout << "$";
       getline(cin,s);
       int firstblank=s.find(' ');
       if (firstblank < s.length()) s[firstblank]='#';
       int secondblank=s.find(' ');
       command=s.substr(0,firstblank);
       if (firstblank < s.length())
         op1=s.substr(firstblank+1,secondblank-firstblank-1);
       if (secondblank < s.length())
         op2=s.substr(secondblank+1);

       if (command=="dir")
          {
		  
		  // use the ls function
	    shell.dir();

	    	
           }

       if (command=="add")
          {
            // The variable op1 is the new file and op2 is the file data
	    if(op2=="bfile1")
		cout<<shell.add(op1,bfile1);
	    else if(op2=="bfile2")
		cout<<shell.add(op1,bfile2);
	    else
	    	cout<<shell.add(op1,op2);

          }

       if (command=="del")
          {
            // The variable op1 is the file
	    cout<<shell.del(op1);

          }

       if (command=="type")
          {
            // The variable op1 is the file
	    cout<<shell.type(op1);

          }

       if (command=="copy")
          {
            // The variable op1 is the source file and the variable op2 is the destination file.
	    cout<<shell.copy(op1,op2);

          }

       if (command=="search")
          {
            // This is the command for Project 4
            // The variable op1 is the date
          }
       
      }

 return 0;
}





