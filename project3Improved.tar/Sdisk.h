#ifndef SDISK_H
#define SDISK_H

#include <string>
#include <fstream>
#include <vector>

using namespace std;

class Sdisk
{
public:
    
	Sdisk(string diskname, int numberofblocks, int blocksize);

	int getblock(int blocknumber, string& buffer);
	int putblock(int blocknumber, string buffer);
	int getnumberofblocks();
	int getblocksize();

private:
   	string diskname;
    	int numberofblocks;
    	int blocksize;
};

class Filesys: public Sdisk
{
public :
	Filesys(string diskname, int numberofblocks, int blocksize);
	int fssynch();
	int fsclose();
	int newfile(string file);
	int rmfile(string file);
	int getfirstblock(string file);
	int addblock(string file, string block);
	int delblock(string file, int blocknumber);
	int readblock(string file, int blocknumber, string& buffer);
	int writeblock(string file, int blocknumber, string buffer);
	int nextblock(string file, int blocknumber);
	vector<string> ls();
	
private :
	int rootsize;           
	int fatsize;            
	vector<string> filename;  
	vector<int> firstblock;
	vector<int> fat;             
};


class Shell: public Filesys
{
public :
Shell(string filename, int numberofblocks, int blocksize);
int dir();// lists all files
int add(string file,string buffer);// add a new file using buffer as data
int del(string file);// deletes the file
int type(string file);//lists the contents of file
int copy(string file1, string file2);//copies file1 to file2
};
/*
class Table : Public Filesys
{
Public :
Table(string diskname,int blocksize,int numberofblocks, string flatfile, string indexfile);
int Build_Table(string input_file);
int Search(string value);
Private :
string flatfile;
string indexfile;
int IndexSearch(string value);
};
*/
vector<string> block(string buffer, int b);

#endif // SDISK_H

